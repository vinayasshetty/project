﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentlib
{
   public class subject
    {
        public string subjectid { get; set; }
        public string subjectname { get; set; }
        public string branchid { get; set; }
        public int semester { get; set; }
    }
}
