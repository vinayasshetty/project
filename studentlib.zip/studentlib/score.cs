﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentlib
{
   public class score
    {
        public string usn { get; set; }
        public string subjectid { get; set; }
        public int marks { get; set; }
        public string grade { get; set; }
    }
}
