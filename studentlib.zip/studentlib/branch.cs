﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentlib
{
    class branch
    {
        public string branchid { get; set; }
        public string branchname { get; set; }
    }
}
